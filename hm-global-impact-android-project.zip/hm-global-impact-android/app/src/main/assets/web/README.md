# HM Global Impact App v2

Phase 2 commercial-app prototype for HM Global Impact.

Included:
- Branded home screen
- Product catalogue
- Search
- Cart
- Checkout/order reference (local prototype)
- Services catalogue
- Orders screen
- Account screen
- Installable PWA manifest/service worker
- HM Global logo assets

Important: product prices are intentionally shown as ₦0 placeholders until the real catalogue/prices are supplied. Payment, live inventory, delivery and customer authentication require the backend phase.

## Phone installation
The PWA must be hosted over HTTPS (for example on the HM Global website). Open the app URL in Chrome on Android and use Chrome's "Install app" / "Add to Home screen" option.

## Native Android
This folder is the UI/prototype foundation. A signed APK/AAB requires an Android build environment and a backend/API for production features.
