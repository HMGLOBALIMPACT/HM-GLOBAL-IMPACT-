package com.hmglobalimpact.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    WebView webView = new WebView(this);
    WebSettings settings = webView.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setAllowFileAccess(true);
    webView.setWebViewClient(new WebViewClient());
    webView.loadUrl("file:///android_asset/web/index.html");
    setContentView(webView);
  }
  @Override public void onBackPressed() {
    WebView w = (WebView) findViewById(android.R.id.content);
    super.onBackPressed();
  }
}
