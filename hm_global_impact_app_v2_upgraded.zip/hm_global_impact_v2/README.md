# HM Global Impact App v2 — Commercial Catalogue Upgrade

This build upgrades the original PWA prototype into a richer commercial catalogue foundation.

## Included in this upgrade
- Real product catalogue records based on the supplied product photos
- Product categories, search and category filtering
- Product detail pages with brand/model/specifications
- Product photography from the supplied images
- Nigerian naira formatting
- Market-reference pricing where a current comparable listing was found
- "Contact for price" for products whose exact model/rating was not sufficiently verified
- Cart with quantity tracking and reference subtotal
- Local order-reference workflow
- Service catalogue
- Customer/account and order screens
- Responsive mobile-first UI
- PWA manifest and service worker retained

## Important pricing note
The catalogue currently uses **market-reference prices**, not HM Global Impact's final selling prices. Before public launch, the business should replace each reference value with its own controlled selling price and stock status.

## Backend phase still required
- Admin dashboard
- Cloud product database
- Live stock management
- Customer authentication
- Real order submission
- Payment gateway
- Delivery/shipping logic
- HM Global Impact WhatsApp number and support contact configuration
- Production analytics and error monitoring

## Phone installation
Host the folder over HTTPS. Open the app URL in Chrome on Android and use Chrome's Install app / Add to Home screen option.
